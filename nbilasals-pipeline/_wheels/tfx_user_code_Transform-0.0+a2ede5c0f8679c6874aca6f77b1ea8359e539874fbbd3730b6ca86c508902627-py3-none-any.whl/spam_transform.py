import tensorflow as tf

LABEL_KEY = "Category"  # Kolom label
FEATURE_KEY = "Message"  # Kolom fitur

def transformed_name(key):
    """Renaming transformed features"""
    return key + "_xf"

def preprocessing_fn(inputs):
    """
    Preprocess input features into transformed features

    Args:
        inputs: map from feature keys to raw features.

    Return:
        outputs: map from feature keys to transformed features.
    """
    outputs = {}

    # Mengubah teks menjadi huruf kecil
    outputs[transformed_name(FEATURE_KEY)] = tf.strings.lower(inputs[FEATURE_KEY])

    # Mengubah label dari 'ham'/'spam' menjadi 0/1
    # Cast the result to tf.int64
    outputs[transformed_name(LABEL_KEY)] = tf.cast(
        tf.where(tf.equal(inputs[LABEL_KEY], b'spam'), 1, 0),
        dtype=tf.int64
    )
    tf.print("Transformed Label:", outputs[transformed_name(LABEL_KEY)])

    return outputs
